package com.gl.jdbc.client;
import com.gl.jdbc.client.*;
public class JdbcClientUI {
	
	public static void main(String[] args)
	{
		EmployeeDataManager edm = new EmployeeDataManager();
		edm.showMenu();
	}

}
