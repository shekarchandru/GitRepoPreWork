package com.gl.jdbc.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.gl.jdbc.model.Employee;
import com.gl.jdbc.service.EmployeeService;

public class EmployeeDataManager {
	
	String reply = "yes";
	int choice;
	Scanner scan1 = new Scanner(System.in);
	EmployeeService eService;
	
	public EmployeeDataManager()
	{
		eService = new EmployeeService();
	}
	
	public void showMenu()
	{
		
		while(reply.equals("yes") || reply.equals("YES"))
		{
			System.out.println("---------------MAIN MENU---------------");
			System.out.println("1. View All Employees");
			System.out.println("2. Get Employee By ID");
			System.out.println("3. Insert Employee");
			System.out.println("4. Update Employee");
			System.out.println("5. Delete Employee");
			System.out.println("6. Exit App");
			System.out.println("Enter Your Choice");
			choice = scan1.nextInt();
			
			switch(choice)
			{
				case 1:
				{
					System.out.println("Viewing All Employees");
					ArrayList <Employee> employees = eService.getAllEmployeesSvc();
					
					Iterator <Employee> empIter = employees.iterator();
					while(empIter.hasNext())
					{
						Employee e = empIter.next();
						System.out.println(e);
					}
					//System.out.println(employees);
					break;
				}
				case 2:
				{
					System.out.println("Get Employee By ID");
					String empId;
					System.out.println("Enter the Employee Id whose record you wish to see");
					empId = scan1.next();
					Employee employee = eService.getEmployeeByIdSvc(empId);
					System.out.println(employee);
					break;
				}
				case 3:
				{
					System.out.println("Insert Employee");
					String eId,eName,eAddr,ePhon;
					float eSal;
					int eITax;
					System.out.println("Enter the Employee Id");
					eId = scan1.next();
					System.out.println("Enter Employee Name");
					eName = scan1.next();
					System.out.println("Enter Employee Address");
					eAddr = scan1.next();
					System.out.println("Enter Employee Phone");
					ePhon = scan1.next();
					System.out.println("Enter Employee Salary");
					eSal = scan1.nextFloat();
					System.out.println("Enter Tax Liability for the employee");
					eITax = scan1.nextInt();
					Employee e = new Employee (eId,eName,eAddr,ePhon,eSal,eITax);
					if(eService.insertEmployeeSvc(e))
					{
						System.out.println("Record Inserted Successfully");
					}
					else
					{
						System.out.println("Sorry Insertion Failed");
					}
					break;
				}
				case 4:
				{
					System.out.println("Update Employee");
					String eId;
					System.out.println("Enter the Id of the Employee whose address you wish to change");
					eId = scan1.next();
					Employee e = eService.getEmployeeByIdSvc(eId);
					System.out.println(e);
					System.out.println("Enter The New Address ");
					String newAddress = scan1.next();
					e.setEmployeeAddress(newAddress);
					if(eService.updateEmployee(e))
					{
						System.out.println("Record Updated Successfully..");
					}
					else
					{
						System.out.println("Sorry Updation Failed...");
					}
					break;
				}
				case 5:
				{
					System.out.println("Delete Employee By ID");
					String empId;
					System.out.println("Enter The Id of the Employee whose Record You wish to delete");
					empId = scan1.next();
					if(eService.deleteEmployeeByIdSvc(empId))
					{
						System.out.println("Record Deleted successfully for Employee with Id "+empId);
					}
					else
					{
						System.out.println("Sorry Deletion Failed");
					}
					break;
				}
				case 6:
				{
					System.out.println("Exiting App");
					System.exit(0);
					break;
				}
				default:
				{
					System.out.println("Sorry Valid Options are 1-6");
					break;
				}
			}
			System.out.println("Do You Wish to Continue yes/no");
			reply = scan1.next();
		}
		
		
		
	}

}
