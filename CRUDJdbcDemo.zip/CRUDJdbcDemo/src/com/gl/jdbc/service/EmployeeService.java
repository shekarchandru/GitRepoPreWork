package com.gl.jdbc.service;

import java.util.ArrayList;

import com.gl.jdbc.dao.EmployeeDao;
import com.gl.jdbc.model.Employee;

public class EmployeeService {

	EmployeeDao empDao;
	
	public EmployeeService()
	{
		empDao = new EmployeeDao();
	}
	
	public ArrayList <Employee> getAllEmployeesSvc()
	{
		//ArrayList <Employee> employees  = empDao.getAllEmployees();
		return empDao.getAllEmployees();
	}
	public Employee getEmployeeByIdSvc(String empId)
	{
		return empDao.getEmployeeById(empId);
	}
	public boolean insertEmployeeSvc(Employee employee)
	{
		return empDao.insertEmployee(employee);
	}

	public boolean updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		return empDao.updateEmployee(e);
		
	}

	public boolean deleteEmployeeByIdSvc(String empId) {
		// TODO Auto-generated method stub
		return empDao.deleteEmployeeById(empId);
	}
}
