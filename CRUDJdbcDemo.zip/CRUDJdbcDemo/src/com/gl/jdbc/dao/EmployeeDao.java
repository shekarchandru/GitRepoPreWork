package com.gl.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.gl.jdbc.connections.MyConnection;
import com.gl.jdbc.model.Employee;

public class EmployeeDao {

	ArrayList <Employee> employees;
	Connection conn;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet rs;
	MyConnection mycon;
	
	public EmployeeDao()
	{
		
		mycon = new MyConnection();
	}
	
	public ArrayList <Employee> getAllEmployees()
	{
		
		conn = mycon.getMyConnection();
		try {
			stmt = conn.createStatement();
			String query = "select * from Employee";
			rs = stmt.executeQuery(query);
			employees = new ArrayList<Employee>();
			while(rs.next())
			{
				Employee employee = new Employee();
				String empId  = rs.getString(1);
				employee.setEmployeeId(empId);
				
				employee.setEmployeeName(rs.getString(2));
				employee.setEmployeeAddress(rs.getString(3));
				employee.setEmployeePhone(rs.getString(4));
				employee.setEmployeeSalary(rs.getFloat(5));
				employee.setIncomeTax(rs.getInt(6));
				employees.add(employee);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employees;
	}
	public Employee getEmployeeById(String empId)
	{
		conn = mycon.getMyConnection();
		//select * from employee where empaddress= ? and empSalary = ?
		String query ="select * from employee where employeeId = ?";
		Employee employee = new Employee();
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1,empId);
			rs = pstmt.executeQuery();
			rs.next();
			
			String emplId,empName,empAddress,empPhone;
			float empSal;
			int incomTax;
			
			emplId = rs.getString(1);
			empName = rs.getString(2);
			empAddress = rs.getString(3);
			empPhone = rs.getString(4);
			empSal = rs.getFloat(5);
			incomTax = rs.getInt(6);
			
			employee  = new Employee(emplId,empName,empAddress,empPhone,empSal,incomTax);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employee;
	}
	
	public boolean insertEmployee(Employee employee)
	{
		conn = mycon.getMyConnection();
		boolean flag = false;
		String query = "insert into Employee values(?,?,?,?,?,?)";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, employee.getEmployeeId());
			pstmt.setString(2, employee.getEmployeeName());
			pstmt.setString(3, employee.getEmployeeAddress());
			pstmt.setString(4, employee.getEmployeePhone());
			pstmt.setFloat(5, employee.getEmployeeSalary());
			pstmt.setInt(6, employee.getIncomeTax());
			
			pstmt.executeUpdate();
			flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
		
		
	}

	public boolean updateEmployee(Employee e) {
		// TODO Auto-generated method stub
		conn = mycon.getMyConnection();
		boolean flag = false;
		String query = "update Employee set employeeAddress = ? where employeeId  = ?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, e.getEmployeeAddress());
			pstmt.setString(2, e.getEmployeeId());
			
			pstmt.executeUpdate();
			flag = true;
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		return flag;
	}

	public boolean deleteEmployeeById(String empId) {
		// TODO Auto-generated method stub
		conn = mycon.getMyConnection();
		boolean flag = false;
		String query = "delete from Employee where employeeId = ?";
		try {
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, empId);
			int count;
			count = pstmt.executeUpdate();
			if(count >= 1)
			{
				flag = true;
			}
			/*else
			{
				flag = false;
			}*/
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}
